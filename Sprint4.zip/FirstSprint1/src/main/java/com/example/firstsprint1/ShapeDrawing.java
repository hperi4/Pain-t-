package com.example.firstsprint1;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
import com.example.firstsprint1.JavaFXApp.DrawingMode;


public class ShapeDrawing {
    private static GraphicsContext gc;
    private double startX, startY, endX, endY;
    private DrawingMode currentDrawingMode = DrawingMode.SQUARE;
    private double lineWidth = 1.0;
    private boolean isShapeDrawingEnabled = true;
    public void setShapeDrawingEnabled(boolean enabled) {
        isShapeDrawingEnabled = enabled;
    }
    public ShapeDrawing(GraphicsContext gc){
        this.gc = gc;
    }

    public void setDrawingMode(DrawingMode mode){
        currentDrawingMode = mode;
    }

    public void setLineWidth(double width){
        lineWidth = width;
    }

    public void setShapePosition(double x, double y){
        startX = x;
        startY = y;
    }
    public void setShapeSize(double width, double height){
        endX = startX + width;
        endY = startY +height;
        drawShape(startX, startY, endX, endY);
    }
    public void drawShape(double startX, double startY, double endX, double endY) {
        gc.setStroke(Color.BLACK); // Set the stroke color
        gc.setLineWidth(lineWidth);

        if(isShapeDrawingEnabled){
            switch (currentDrawingMode) {
                case SQUARE:
                    double width = Math.abs(endX - startX);
                    double height = Math.abs(endY - startY);
                    double size = Math.min(width, height);
                    gc.strokeRect(startX, startY, size, size);
                    break;
                case CIRCLE:
                    double radius = Math.sqrt(Math.pow(endX - startX, 2) + Math.pow(endY - startY, 2)) / 2;
                    double centerX = (startX + endX) / 2;
                    double centerY = (startY + endY) / 2;
                    gc.strokeOval(centerX - radius, centerY - radius, 2 * radius, 2 * radius);
                    break;
                case TRIANGLE:
                    double baseCenterX = (startX + endX) / 2;
                    double baseCenterY = (startY + endY) / 2;
                    double triangleHeight = Math.abs(endY - startY);
                    double halfBase = Math.abs(endX - startX) / 2;
                    double[] xPoints = { baseCenterX, baseCenterX - halfBase, baseCenterX + halfBase };
                    double[] yPoints = { baseCenterY - triangleHeight / 2, baseCenterY + triangleHeight / 2, baseCenterY + triangleHeight / 2 };
                    gc.strokePolygon(xPoints, yPoints, 3);
                    break;
                case RECTANGLE:
                    double widthRect = Math.abs(endX - startX);
                    double heightRect = Math.abs(endY - startY);
                    gc.strokeRect(startX, startY, widthRect, heightRect);
                    break;
                case ELLIPSE:
                    double widthEllipse = Math.abs(endX - startX);
                    double heightEllipse = Math.abs(endY - startY);
                    gc.strokeOval(startX, startY, widthEllipse, heightEllipse);
                    break;
            }
        }
    }
}

    /*

    public void drawSquare(){
        gc.fillRect(x, y, width, height);
    }
    public void drawCircle(){
        gc.fillOval(x, y, width, height);
    }
    public void drawRectangle(){
        gc.fillRect(x, y, width, height);
    }
    public void drawEllipse(){
        gc.fillOval(x, y, width, height);
    }
    public static void drawTriangle(double x1, double y1,double x2,double y2,double x3,double y3){
        double[] xpoints = {x1, x2, x3};
        double[] ypoints = {y1, y2, y3};
        gc.fillPolygon(xpoints, ypoints, 3);
    }
}

     */
