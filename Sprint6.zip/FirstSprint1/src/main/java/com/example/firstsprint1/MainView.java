/*package com.example.firstsprint1;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.scene.canvas.Canvas;
import javafx.scene.control.MenuBar;
import javafx.scene.control.Menu;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

import java.awt.*;

public class MainView {
    private final VBox view;
    public MainView(Stage primaryStage){
        Canvas canvas = new Canvas();
        ImageView imageView = new ImageView();

        Image image = new Image("path_to_your_image.png");
        imageView.setImage(image);

        GraphicsContext gc = canvas.getGraphicsContext2D();

        gc.drawImage(image, 0, 0, canvas.getWidth(), canvas.getHeight());

        MenuBar menuBar = new MenuBar();
        Menu menu1 = new Menu("File");

        StackPane stackPane = new StackPane(imageView, canvas);

        MainControl control = new MainControl(canvas, primaryStage, menu1, stackPane);

        menuBar.getMenus().add(menu1);

        //view = new VBox(menuBar, stackPane);
        view = new VBox(stackPane);

        imageView.imageProperty().addListener((obs, oldImage, newImage) -> {
            if (newImage != null){
                DrawingLine drawingLine = new DrawingLine(stackPane, canvas);
                stackPane.getChildren().setAll(canvas, drawingLine.getCanvas());
            }
        });

        canvas.setOnMousePressed(event -> {
            double x = event.getX();
            double y = event.getY();
            GraphicsContext gc = canvas.getGraphicsContext2D();
            gc.beginPath();
            gc.moveTo(x, y);
            gc.setStroke(Color.BLACK);
            gc.setLineWidth(2.0);
            gc.stroke();
        });

        canvas.setOnMouseDragged(event -> {
            double x = event.getX();
            double y = event.getY();
            GraphicsContext gc = canvas.getGraphicsContext2D();
            gc.lineTo(x, y);
            gc.stroke();
        });
    }

    public VBox getView(){
        return view;
    }
}

 */

