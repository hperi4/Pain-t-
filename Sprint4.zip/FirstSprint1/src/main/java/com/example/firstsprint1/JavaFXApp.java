package com.example.firstsprint1;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.Cursor;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.input.*;
import javafx.scene.control.*;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.scene.image.WritableImage;
import javafx.scene.shape.DrawMode;
import javafx.stage.Stage;
import java.io.File;
import java.util.Optional;
import java.util.Stack;

public class JavaFXApp extends Application {
    private Slider lineSizeSlider;
    private DrawingLine drawingCanvas;
    private final openImage imageOpener = new openImage();
    private final saveImage imageSaver = new saveImage();
    private final saveImageAs imageSaverAs = new saveImageAs();
    private boolean unsavedChanges = false;
    colorPicker CPick = new colorPicker();
    private File openImgFile;
    private boolean isDrawingEnabled = true;
    private boolean isShapeDrawingEnabled = true;
    private double startX, startY;
    private boolean isEraserMode = false;
    private Stack<Image> undoStack = new Stack<>();                 //necessary for undo and redo
    private Stack<Image> redoStack = new Stack<>();
    private boolean textPlacementMode = false;

    public enum DrawingMode {
        SQUARE, CIRCLE, TRIANGLE, RECTANGLE, ELLIPSE         //define a set of constant values
    }
    public static void main(String[] args) {
        launch(args);
    }
    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("JavaFX App");
        primaryStage.setMaximized(true);

        MenuBar menuBar = new MenuBar();
        Menu fileMenu = new Menu("File");
        Menu editMenu = new Menu("Edit");         //creates all the menu bar options
        Menu helpMenu = new Menu("Help");
        Menu shapesMenu = new Menu("Shapes");
        Menu drawMenu = new Menu("Drawing Options");
        Menu eraseMenu = new Menu("Erasing tools");

        MenuItem menuItem1 = new MenuItem("Open");
        MenuItem menuItem2 = new MenuItem("Save As");
        MenuItem menuItem3 = new MenuItem("Save");
        MenuItem menuItem4 = new MenuItem("Close");
        MenuItem menuItem5 = new MenuItem("Color");                               //creates all the buttons
        MenuItem menuItem6 = new MenuItem("Change Line Size");
        MenuItem menuItem7 = new MenuItem("About");
        MenuItem menuItem8 = new MenuItem("Contact");
        MenuItem drawSquare = new MenuItem("Square");
        MenuItem drawCircle = new MenuItem("Circle");
        MenuItem drawRectangle = new MenuItem("Rectangle");
        MenuItem drawEllipse = new MenuItem("Ellipse");
        MenuItem drawTriangle = new MenuItem("Triangle");
        MenuItem resizeMenuItem = new MenuItem("Resize Canvas");
        MenuItem enableDrawing = new MenuItem("Enable Drawing");
        MenuItem disableDrawing = new MenuItem("Disable Drawing");
        MenuItem enableShapeDrawing = new MenuItem("Enable Shape Drawing");
        MenuItem disableShapeDrawing = new MenuItem("Disable Shape Drawing");
        MenuItem buttonClear = new MenuItem("Clear");
        MenuItem enableEraser = new MenuItem("Enable Eraser");
        MenuItem disableEraser = new MenuItem("Disable Eraser");
        MenuItem undoItem = new MenuItem("Undo");
        MenuItem redoItem = new MenuItem("Redo");
        MenuItem textItem = new MenuItem("Text");

        fileMenu.getItems().addAll(menuItem1, menuItem2, menuItem3, menuItem4);
        editMenu.getItems().addAll(menuItem5,menuItem6, resizeMenuItem);
        helpMenu.getItems().addAll(menuItem7, menuItem8);                                   //places the buttons within all the options on the menu bar
        shapesMenu.getItems().addAll(drawSquare, drawCircle, drawEllipse, drawRectangle, drawTriangle);
        drawMenu.getItems().addAll(enableDrawing, disableDrawing, enableShapeDrawing, disableShapeDrawing, textItem);
        eraseMenu.getItems().addAll(enableEraser, disableEraser, undoItem, redoItem, buttonClear);
        menuBar.getMenus().addAll(fileMenu, editMenu, helpMenu,shapesMenu, drawMenu, eraseMenu);

        drawingCanvas = new DrawingLine(800, 600);

        menuItem1.setOnAction(event ->{
            openImgFile = imageOpener.openImg(primaryStage, drawingCanvas);       //action lisener for when user selects open
        });
        menuItem2.setOnAction(event ->{
            imageSaverAs.saveImgAs(drawingCanvas);         //action listener for when user selects SaveAs
        });
        menuItem3.setOnAction(event ->{
            File currentFile = imageSaver.getCurrentImageFile();                //action listener for when user selects Save
            if(currentFile != null){
                imageSaver.saveImg(drawingCanvas, currentFile);
                unsavedChanges = false;
            } else {
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setTitle("No File Selected");                  //alerts user if no file is selected
                alert.setHeaderText(null);
                alert.setContentText("Open or save a file before using save");
                alert.showAndWait();
            }
        });
        menuItem4.setOnAction(event -> {      // "->" is the lambda operator, which separates the parameter from the body of the lambda expression
            primaryStage.close();             //action listener for when user selects Close
        });
        menuItem5.setOnAction(event -> {
            CPick.showColorPicker();          //action listener for when user selects a color
        });
        menuItem6.setOnAction(event -> {
            lineSizeSlider = new Slider(0, 50, drawingCanvas.getLwidth());   //creates the slider with a range of 0-50
            lineSizeSlider.setShowTickMarks(true);    //tick marks
            lineSizeSlider.setShowTickLabels(true);   //adds numbers to the tick marks
            lineSizeSlider.setMajorTickUnit(5.0);     //major tick marks ever 5 increments
            lineSizeSlider.valueProperty().addListener((observable, oldValue, newValue) -> {
                int newWidth = newValue.intValue();
                drawingCanvas.setLwidth(newWidth);
            });

            VBox sliderBox = new VBox(lineSizeSlider);
            Scene sliderScene = new Scene(sliderBox, 200, 100);
            Stage sliderStage = new Stage();                                //creation of the layout for the slider window
            sliderStage.setScene(sliderScene);
            sliderStage.setTitle("Line Width");
            sliderStage.show();
        });
        GraphicsContext graphicsContext = drawingCanvas.getGraphicsContext2D();
        ShapeDrawing shapeDrawing = new ShapeDrawing(graphicsContext);

        drawSquare.setOnAction(event ->{
            if(isShapeDrawingEnabled){
                shapeDrawing.setDrawingMode(DrawingMode.SQUARE);                       //this and the following similar code are action listeners for when user selects shape
                drawingCanvas.setOnMouseReleased(e -> {
                    shapeDrawing.setShapeSize(e.getX() - startX, e.getY() - startY);   //allows the user to drag on canvas for size of shape
                });
            }
        });
        drawCircle.setOnAction(event ->{
            if(isShapeDrawingEnabled){
                shapeDrawing.setDrawingMode(DrawingMode.CIRCLE);
                drawingCanvas.setOnMouseReleased(e -> {
                    shapeDrawing.setShapeSize(e.getX() - startX, e.getY() - startY);
                });
            }
        });
        drawRectangle.setOnAction(event ->{
            if(isShapeDrawingEnabled){
                shapeDrawing.setDrawingMode(DrawingMode.RECTANGLE);
                drawingCanvas.setOnMouseReleased(e -> {
                    shapeDrawing.setShapeSize(e.getX() - startX, e.getY() - startY);
                });
            }
        });
        drawEllipse.setOnAction(event ->{
            if(isShapeDrawingEnabled){
                shapeDrawing.setDrawingMode(DrawingMode.ELLIPSE);
                drawingCanvas.setOnMouseReleased(e -> {
                    shapeDrawing.setShapeSize(e.getX() - startX, e.getY() - startY);
                });
            }
        });
        drawTriangle.setOnAction(event ->{
            if(isShapeDrawingEnabled){
                shapeDrawing.setDrawingMode(DrawingMode.TRIANGLE);
                drawingCanvas.setOnMouseReleased(e -> {
                    shapeDrawing.setShapeSize(e.getX() - startX, e.getY() - startY);
                });
            }
        });

        primaryStage.setOnCloseRequest(event ->{
            event.consume();
            checkUnsavedChanges();
        });

        resizeMenuItem.setOnAction(event ->{
            resizeCanvas();
        });

        enableDrawing.setOnAction(event ->{
            drawingCanvas.setDrawingEnabled(true);     //these are action listeners for when the user enables or disables drawing or shape drawing
        });
        disableDrawing.setOnAction(event ->{
            drawingCanvas.setDrawingEnabled(false);
        });
        enableShapeDrawing.setOnAction(event ->{
            shapeDrawing.setShapeDrawingEnabled(true);
        });
        disableShapeDrawing.setOnAction(event ->{
            shapeDrawing.setShapeDrawingEnabled(false);
        });

        buttonClear.setOnAction(e ->{
            clearCanvas();               //clears the canvas
        });

        drawingCanvas.setOnMousePressed(event -> {
            if (isDrawingEnabled) {
                shapeDrawing.setShapePosition(event.getX(), event.getY());
            }
        });

        enableEraser.setOnAction(event ->{
            isEraserMode = true;   //sets eraser to enabled
            disableDrawing.setDisable(true);   //disables drawing so user cannot draw and erase
            enableEraser.setDisable(true);     //disables the enable eraser button so user cannot select it
            disableEraser.setDisable(false);   //enables use of disable eraser
            drawingCanvas.setCursor(Cursor.CROSSHAIR);   //changes the cursor
        });
        disableEraser.setOnAction(event ->{
            isEraserMode = false;
            disableDrawing.setDisable(false);
            enableEraser.setDisable(false);
            disableEraser.setDisable(true);
            drawingCanvas.setCursor(Cursor.DEFAULT);
        });

        drawingCanvas.setOnMousePressed(event -> {
            saveState();
            if (isDrawingEnabled) {
                drawingCanvas.startDrawing(event);
            }
        });
        drawingCanvas.setOnMouseDragged(event -> {
            double x = event.getX();
            double y = event.getY();         // retrieves x and y cords of mouse position
            if(isEraserMode){
                double eraserSize = 10.0;    //sets eraser size if eraser is enabled
                drawingCanvas.erase(x,y,eraserSize);   //calls erase at x and y of mouse cord
            }else if (isDrawingEnabled){
                drawingCanvas.startDrawing(event);    //if drawing is enabled the user can draw
            }
        });

        textItem.setOnAction(event -> {
            textPlacementMode = !textPlacementMode;
            if (textPlacementMode){
                showAlert("Text Placement","Click on the canvas to place text.","");
                drawingCanvas.setOnMouseClicked(event1 -> handleTextPlacement(event1));
            } else {
                drawingCanvas.setOnMouseClicked(null);
            }
        });

        undoItem.setOnAction(e -> {
            undoItem();
        });
        redoItem.setOnAction(e -> {
            redoItem();
        });

        KeyCombination saveCombination = new KeyCodeCombination(KeyCode.S, KeyCombination.CONTROL_DOWN);
        primaryStage.addEventFilter(KeyEvent.KEY_PRESSED, event ->{
            if(saveCombination.match(event)){
                File currentFile = imageSaver.getCurrentImageFile();      //retrieves the image
                if (currentFile != null){
                    imageSaver.saveImg(drawingCanvas, currentFile);       //saves the image
                    unsavedChanges = false;
                } else {
                    Alert alert = new Alert(Alert.AlertType.WARNING);
                    alert.setTitle("No File Selected");
                    alert.setHeaderText(null);
                    alert.setContentText("Open or save a file before using save");    //alert if no file is selected to save
                    alert.showAndWait();
                }
                event.consume();
            }
        });

        double[] pointA = {0.0, 0.0};
        drawingCanvas.setOnMouseClicked(event ->{
            if(drawingCanvas.isDrawingEnabled()){
                if(pointA[0] == 0.0 && pointA[1] == 0){   //checks if both points are 0
                    pointA[0] = event.getX();  //click 1 sets x to location clicked
                    pointA[1] = event.getY();  //click 2 sets y to location clicked
                } else{
                    double x1 = pointA[0];
                    double y1 = pointA[1];
                    double x2 = event.getX();
                    double y2 = event.getY();
                    drawLine(x1, y1, x2, y2);    //connects the points together
                    pointA[0] = 0.0;
                    pointA[1] = 0.0;    //resets so that user can do another line
                }
            }
        });

        VBox vBox = new VBox(menuBar);
        vBox.setAlignment(Pos.CENTER);

        BorderPane borderPane = new BorderPane();
        borderPane.setCenter(drawingCanvas);
        borderPane.setTop(vBox);

        Scene scene = new Scene(borderPane);
        primaryStage.setScene(scene);
        primaryStage.show();
    }
    private void clearCanvas() {
        GraphicsContext gc = drawingCanvas.getGraphicsContext2D();
        gc.clearRect(0, 0, drawingCanvas.getWidth(), drawingCanvas.getHeight());    //clears the canvas by specifies the size of the canvas and then erases it
    }
    private void resizeCanvas(){
        TextInputDialog dialog = new TextInputDialog();
        dialog.setTitle("Resize Canvas");
        dialog.setHeaderText("Enter new canvas dimensions (w x h):");
        dialog.setContentText("Format: w x h");
        Optional<String> result = dialog.showAndWait();
        if (result.isPresent()){
            String[] dimensions = result.get().split("x");
            if (dimensions.length == 2){
                try{
                    double newWidth = Double.parseDouble(dimensions[0].trim());     //extracts width from first element.
                    double newHeight= Double.parseDouble(dimensions[1].trim());     //extracts height of second element.
                    if(newWidth < 100 || newHeight < 100){
                        showAlert("ERROR", "Mimimum Size Exceeded", "Please set W and H to be at lease 100.");
                    } else{
                        double currentWidth = drawingCanvas.getWidth();
                        double currentHeight = drawingCanvas.getHeight();
                        double aspectRatio = currentWidth / currentHeight;
                        if (newWidth / newHeight > aspectRatio){
                            drawingCanvas.setWidth(newHeight * aspectRatio);
                            drawingCanvas.setHeight(newHeight);
                        } else {
                            drawingCanvas.setWidth(newWidth);
                            drawingCanvas.setHeight(newWidth / aspectRatio);
                        }
                    }
                } catch (NumberFormatException e){
                    showAlert("Invalid input", "Enter number", "input must be w x h");
                }
            } else {
                showAlert("Invalid input", "Enter number", "input must be w x h");
            }
        }
    }
    private void showAlert(String title, String headerText, String contentText) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(headerText);
        alert.setContentText(contentText);
        alert.showAndWait();
    }

    private void checkUnsavedChanges(){
        if(unsavedChanges){
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Unsaved Changes");
            alert.setHeaderText("You have unsaved changes.");
            alert.setContentText("Do you wish to save before closing?");

            ButtonType saveButton = new ButtonType("Save");
            ButtonType discardButton = new ButtonType("Discard");
            ButtonType cancelButton = new ButtonType("Cancel");

            alert.getButtonTypes().setAll(saveButton, discardButton, cancelButton);

            Optional<ButtonType> result = alert.showAndWait();
            if (result.isPresent()){
                if(result.get()== saveButton){
                    imageSaver.saveImg(drawingCanvas, openImgFile);
                    unsavedChanges = false;
                    Platform.exit();
                }else if (result.get() == discardButton){
                    unsavedChanges = false;
                    Platform.exit();
                }
            }
        } else{
            Platform.exit();
        }
    }

    private void drawLine(double x1, double y1, double x2, double y2){
        if (drawingCanvas.isDrawingEnabled()){
            GraphicsContext gc = drawingCanvas.getGraphicsContext2D();
            gc.strokeLine(x1, y1, x2, y2);
        }
    }

    private void saveState(){
        WritableImage snapshot = drawingCanvas.snapshot(null, null);
        undoStack.push(snapshot);
        redoStack.clear();
    }

    public void undoItem(){
        if(!undoStack.isEmpty()){
            redoStack.push(drawingCanvas.snapshot(null, null));   //gives redo a snapshot of the canvas so redo can work
            Image lastState = undoStack.pop();     //retrieves the last state of the image from undo stack
            GraphicsContext gc = drawingCanvas.getGraphicsContext2D();
            gc.clearRect(0, 0, drawingCanvas.getWidth(), drawingCanvas.getHeight());
            gc.drawImage(lastState, 0, 0, drawingCanvas.getWidth(), drawingCanvas.getHeight());
        }
    }
    public void redoItem() {
        if (!redoStack.isEmpty()) {
            undoStack.push(drawingCanvas.snapshot(null, null));   //saves current state of drawingCanvas
            Image lastState = redoStack.pop();
            GraphicsContext gc = drawingCanvas.getGraphicsContext2D();
            gc.clearRect(0, 0, drawingCanvas.getWidth(), drawingCanvas.getHeight());
            gc.drawImage(lastState, 0, 0, drawingCanvas.getWidth(), drawingCanvas.getHeight());   // redo the last drawing action
        }
    }
    private void handleTextPlacement(MouseEvent event) {
        if (textPlacementMode) {
            double x = event.getX();
            double y = event.getY();
            TextInputDialog dialog = new TextInputDialog();
            dialog.setTitle("Add Text");
            dialog.setHeaderText("Enter Text");
            dialog.setContentText("Text");
            Optional<String> result = dialog.showAndWait();

            if (result.isPresent()) {
                String text = result.get();
                GraphicsContext gc = drawingCanvas.getGraphicsContext2D();
                gc.fillText(text, x, y);
                textPlacementMode = false; // Disable text placement after placing text
            }
        }
    }
}