package com.example.firstsprint1;

import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.canvas.Canvas;

public class DrawingLine extends Canvas {
    private GraphicsContext gc;
    private int linewidth = 2;
    private Color fillColor = Color.BLACK;
    private boolean isDrawingEnabled = true;
    public DrawingLine(double width, double height) {     // Constructor for the DrawingCanvas class, taking width and height as parameters
        super(width, height);                                   // Call constructor of the Canvas class with specified width and height
        gc = getGraphicsContext2D();                            // Get GraphicsContext for drawing on the canvas
        gc.setLineWidth(linewidth);

        gc.setStroke(Color.BLACK);

        setOnMousePressed(this::startDrawing);                  // When mouse pressed call startDrawing method
        setOnMouseDragged(this::continueDrawing);               // When mouse dragged call continueDrawing method
        setOnMouseReleased(this::stopDrawing);                  // When mouse released call stopDrawing method
    }
    public void colorChanger(Color color) {
        gc.setFill(color);
    }
    public void startDrawing(MouseEvent event) {
        if (isDrawingEnabled){
            gc.beginPath();                                          // Begin new path for drawing
            gc.lineTo(event.getX(), event.getY());                   // Move drawing cursor to mouse click location
            gc.stroke();                                             // Perform stroke operation to start drawing
        }
    }
    private void continueDrawing(MouseEvent event) {
        if (isDrawingEnabled){
            gc.lineTo(event.getX(), event.getY());                    // Extend path to current mouse position
            gc.stroke();                                              // Perform stroke operation to continue drawing
        }
    }
    private void stopDrawing(MouseEvent event) {
        if (isDrawingEnabled){
            gc.closePath();
        }
    }
    public void setDrawingEnabled(boolean enabled){
        isDrawingEnabled = enabled;
    }
    public boolean isDrawingEnabled(){
        return this.isDrawingEnabled;
    }
    public void setLwidth(int newWidth) {
        linewidth = newWidth;                           // Update line width
        gc.setLineWidth(linewidth);                     // Set new line width in GraphicsContext
    }
    public int getLwidth() {
        return linewidth;
    }

    public void erase(double x, double y , double eraserSize){
        if (isDrawingEnabled){
            GraphicsContext gc = getGraphicsContext2D();
            gc.clearRect(x - eraserSize / 2, y - eraserSize / 2, eraserSize, eraserSize);
        }
    }
}


