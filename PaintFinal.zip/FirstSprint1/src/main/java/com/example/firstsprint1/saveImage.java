/**
 * Manages the saving and auto-saving functionality for a Canvas-based drawing application.
 * The class provides methods for saving the current state of the Canvas, initiating a "Save As" dialog,
 * starting and stopping auto-save, and retrieving the current image file.
 *
 * This class utilizes JavaFX's Canvas and FileChooser for handling the drawing canvas and file selection.
 * It includes an inner class, AutoSaveTask, which extends TimerTask to perform auto-saving based on a set interval.
 */
package com.example.firstsprint1;

import javafx.embed.swing.SwingFXUtils;
import javafx.scene.SnapshotParameters;
import javafx.scene.canvas.Canvas;
import javafx.scene.image.Image;
import javafx.scene.image.WritableImage;
import javafx.stage.FileChooser;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.awt.image.RenderedImage;
import java.io.File;
import java.io.IOException;
import java.util.Timer;
import java.util.TimerTask;

public class saveImage {
    private File currentImageFile = null;
    private boolean unsavedChanges = false;
    private Timer autoSaveTimer;
    private static final int AUTO_SAVE_INTERVAL = 60000;
    private Canvas canvas;
    private boolean autoSaveEnabled = true;

    public saveImage(){
        this.canvas = canvas;
        autoSaveTimer = new Timer(true);
        autoSaveTimer.schedule(new AutoSaveTask(currentImageFile),AUTO_SAVE_INTERVAL, AUTO_SAVE_INTERVAL);
    }

    /**
     * Saves the content of a Canvas to the current image file or initiates a "Save As" dialog if no file is associated.
     *
     * @param canvas The Canvas whose content is to be saved.
     *
     * The method checks if a Canvas object is provided. If the Canvas is not null, it creates a WritableImage
     * with the same dimensions as the Canvas and takes a snapshot of the Canvas content. The WritableImage is then
     * converted to a BufferedImage, and the content is saved to the current image file or a new file based on the
     * "Save As" dialog if no file is associated. The method updates the current image file and marks the canvas
     * content as saved, or initiates a "Save As" dialog if the canvas is null.
     */
    public void saveImg(Canvas canvas) {
        if (canvas != null) {
            int width = (int) canvas.getWidth();
            int height = (int) canvas.getHeight();

            WritableImage writableImage = new WritableImage(width, height);         // Create writable image with the same dimensions as the Canvas
            Image img = canvas.snapshot(new SnapshotParameters(), writableImage);               // Take snapshot of the Canvas content

            BufferedImage bImage = SwingFXUtils.fromFXImage(img, null);     // Converting the Writable Image to a Buffered Image

            String format = currentImageFile.getName().toLowerCase().endsWith(".png") ? "png" : "jpg";
            try {
                ImageIO.write(bImage, format, currentImageFile);   // Write BufferedImage to specified image file
                System.out.println("Image Saved at: " + currentImageFile.getAbsolutePath());
                unsavedChanges = false;
            } catch (IOException e) {
                e.printStackTrace();                                // Handle any input/output exceptions that may occur
            }
        } else {
            saveImgAs(canvas);
        }
    }

    /**
     * Initiates a "Save As" dialog for saving the content of a Canvas to a specified file.
     *
     * @param canvas
     *
     * The method displays a "Save As" dialog, allowing the user to choose a file location and format for saving
     * the Canvas content. The supported file formats include PNG, JPEG, GIF, and BMP. If a file is selected,
     * the current image file is updated to the selected file.
     */
    public void saveImgAs(Canvas canvas) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Save As");
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("PNG Files", "*.png"),
                new FileChooser.ExtensionFilter("JPEG Files", "*.jpg", "*.jpeg"),
                new FileChooser.ExtensionFilter("GIF Files", "*.gif"),
                new FileChooser.ExtensionFilter("BMP Files", "*.bmp")
        );
        File selectedFile = fileChooser.showSaveDialog(null);

        if (selectedFile != null) {
            currentImageFile = selectedFile; // Update currentImageFile
        }
    }

    /**
     * Retrieves the current image file associated with this instance.
     *
     * @return The current image file, or null if no file is associated.
     *
     * The method returns the File object representing the current image file associated with this instance.
     * If no file is associated, it returns null.
     */
    public File getCurrentImageFile(){
        return currentImageFile;
    }

    /**
     * Starts the auto-save functionality at a specified interval.
     *
     * The method enables the auto-save functionality and initializes a TimerTask to perform auto-saving
     * at a specified interval. If the auto-save timer is not already running, it is created and scheduled.
     */
    public void startAutoSave() {
        autoSaveEnabled = true;
        if (autoSaveTimer == null) {
            autoSaveTimer = new Timer(true);
            autoSaveTimer.schedule(new AutoSaveTask(currentImageFile), AUTO_SAVE_INTERVAL, AUTO_SAVE_INTERVAL);
        }
    }

    /**
     * Stops the auto-save functionality.
     *
     * The method disables the auto-save functionality and cancels the auto-save timer if it is currently running.
     *
     */
    public void stopAutoSave() {
        autoSaveEnabled = false;
        if (autoSaveTimer != null) {
            // Cancel the auto-save timer
            autoSaveTimer.cancel();
            autoSaveTimer = null;
        }
    }

    /**
     * Represents a TimerTask for performing auto-saving operations.
     *
     * The AutoSaveTask class extends TimerTask and is responsible for checking unsaved changes and
     * triggering the saveImg method at regular intervals if auto-saving is enabled and a file is associated.
     */
    class AutoSaveTask extends TimerTask{
        private File currentFile;

        public AutoSaveTask(File currentFile){
            this.currentFile = currentFile;
        }
        @Override
        public void run(){
            if (unsavedChanges && currentFile != null){
                saveImg(canvas);
                unsavedChanges = false;
                System.out.println("Auto-saved.");
            } else {
                System.out.println("Auto-save skipped: Auto-save did not detect a file.");
            }
        }
    }
}
