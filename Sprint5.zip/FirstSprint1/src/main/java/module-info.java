module com.example.firstsprint1 {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.desktop;
    requires javafx.swing;
    requires org.junit.jupiter.api;


    opens com.example.firstsprint1 to javafx.fxml;
    exports com.example.firstsprint1;
}