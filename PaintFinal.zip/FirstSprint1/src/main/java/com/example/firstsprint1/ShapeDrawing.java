/**
 * This class allows the drawing of various shapes on the canvas.
 */
package com.example.firstsprint1;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
import com.example.firstsprint1.JavaFXApp.DrawingMode;


public class ShapeDrawing {
    private static GraphicsContext gc;
    private DrawingMode currentDrawingMode = DrawingMode.SQUARE;
    private double lineWidth = 1.0;
    private boolean isShapeDrawingEnabled = true;
    public void setShapeDrawingEnabled(boolean enabled) {
        isShapeDrawingEnabled = enabled;
    }
    public ShapeDrawing(GraphicsContext gc){
        this.gc = gc;
    }
    public void setDrawingMode(DrawingMode mode){
        currentDrawingMode = mode;
    }

    /**
     * Draws a geometric shape on the canvas based on the specified coordinates.
     *
     * @param startX The x-coordinate of the starting point of the shape.
     * @param startY The y-coordinate of the starting point of the shape.
     * @param endX The x-coordinate of the ending point of the shape.
     * @param endY The y-coordinate of the ending point of the shape.
     *
     * The method sets the stroke color and line width using the GraphicsContext (gc).
     * If shape drawing is enabled, it determines the current drawing mode and draws
     * the corresponding geometric shape on the canvas based on the specified coordinates.
     *
     * The supported drawing modes include:
     * - SQUARE: Draws a square with the specified starting and ending points.
     * - CIRCLE: Draws a circle with the specified starting and ending points.
     * - TRIANGLE: Draws an equilateral triangle with the specified starting and ending points.
     * - RECTANGLE: Draws a rectangle with the specified starting and ending points.
     * - ELLIPSE: Draws an ellipse with the specified starting and ending points.
     */
    public void drawShape(double startX, double startY, double endX, double endY) {
        gc.setStroke(Color.BLACK); // Set the stroke color
        gc.setLineWidth(lineWidth);

        if(isShapeDrawingEnabled){
            switch (currentDrawingMode) {
                case SQUARE:
                    double width = Math.abs(endX - startX);
                    double height = Math.abs(endY - startY);
                    double size = Math.min(width, height);
                    gc.strokeRect(startX, startY, size, size);
                    break;
                case CIRCLE:
                    double radius = Math.sqrt(Math.pow(endX - startX, 2) + Math.pow(endY - startY, 2)) / 2;
                    double centerX = (startX + endX) / 2;
                    double centerY = (startY + endY) / 2;
                    gc.strokeOval(centerX - radius, centerY - radius, 2 * radius, 2 * radius);
                    break;
                case TRIANGLE:
                    double baseCenterX = (startX + endX) / 2;
                    double baseCenterY = (startY + endY) / 2;
                    double triangleHeight = Math.abs(endY - startY);
                    double halfBase = Math.abs(endX - startX) / 2;
                    double[] xPoints = { baseCenterX, baseCenterX - halfBase, baseCenterX + halfBase };
                    double[] yPoints = { baseCenterY - triangleHeight / 2, baseCenterY + triangleHeight / 2, baseCenterY + triangleHeight / 2 };
                    gc.strokePolygon(xPoints, yPoints, 3);
                    break;
                case RECTANGLE:
                    double widthRect = Math.abs(endX - startX);
                    double heightRect = Math.abs(endY - startY);
                    gc.strokeRect(startX, startY, widthRect, heightRect);
                    break;
                case ELLIPSE:
                    double widthEllipse = Math.abs(endX - startX);
                    double heightEllipse = Math.abs(endY - startY);
                    gc.strokeOval(startX, startY, widthEllipse, heightEllipse);
                    break;
            }
        }
    }
}
