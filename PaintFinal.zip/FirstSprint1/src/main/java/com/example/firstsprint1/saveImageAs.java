
/**
 * Saves the contents of canvas to a image file
 * Users can use the extension (PNG, JPEG, GIF, BMP)
 */
package com.example.firstsprint1;

import javafx.scene.SnapshotParameters;
import javafx.scene.image.WritableImage;
import javafx.stage.FileChooser;
import javafx.scene.canvas.Canvas;
import javafx.embed.swing.SwingFXUtils;

import javax.imageio.ImageIO;
import java.io.IOException;
import java.awt.image.BufferedImage;
import java.io.File;

public class saveImageAs {

    /**
     * Allows the user to save the content of a Canvas to a file using a "Save As" dialog.
     *
     * @param canvas The Canvas whose content is to be saved.
     *
     * The method displays a file save dialog allowing the user to choose the file format
     * and location for saving the Canvas content. The supported file formats include PNG,
     * JPEG, GIF, and BMP. The Canvas content is converted to a BufferedImage and saved to
     * the selected file with the specified format.
     */
    public void saveImgAs(Canvas canvas) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Save As");
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("PNG Files", "*.png"),
                new FileChooser.ExtensionFilter("JPEG Files", "*.jpg", "*.jpeg"),
                new FileChooser.ExtensionFilter("GIF Files", "*.gif"),
                new FileChooser.ExtensionFilter("BMP Files", "*.bmp")
        );
        File selectedFile = fileChooser.showSaveDialog(null);       // Show the file save dialog
        if (selectedFile != null) {
            String format = selectedFile.getName().toLowerCase().endsWith(".png") ? "png" : "jpg";
            int width = (int) canvas.getWidth();                    // Get width of Canvas
            int height = (int) canvas.getHeight();                  // Get height of Canvas
            WritableImage writableImage = new WritableImage(width, height);     // Create WritableImage from Canvas content
            canvas.snapshot(new SnapshotParameters(), writableImage);
            BufferedImage bImage = SwingFXUtils.fromFXImage(writableImage, null);   // Converting Writable image to Buffered Image
            try {
                ImageIO.write(bImage, format, selectedFile);         // Write BufferedImage to the selected file with determined format
            } catch (IOException e) {
                e.printStackTrace();                                 // Handle any input/output exceptions that may occur during saving
            }
        }
    }
}
