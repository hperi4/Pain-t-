



/* package com.example.firstsprint1;

import javafx.application.Application;
import javafx.embed.swing.SwingFXUtils;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.*;
import javafx.scene.control.Button;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.scene.paint.Color;
import javafx.scene.input.MouseEvent;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.concurrent.atomic.AtomicInteger;

public class MainControl extends Application {
    private Canvas canvas;
    private File lastSavedFile;
    private GraphicsContext gc;
    private ImageView imageView;
    //private File currentFile = null;
    //private StackPane root = new StackPane();
    private DrawingLine drawingLine;


    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        this.canvas = new Canvas(800, 600);
        this.imageView = new ImageView();
        this.gc = canvas.getGraphicsContext2D();

        MenuBar menuBar = new MenuBar();
        Menu menu1 = new Menu("File");
        MenuItem menuItem1 = new MenuItem("Open");
        MenuItem menuItem2 = new MenuItem("Save As");
        MenuItem menuItem3 = new MenuItem("Save");
        MenuItem menuItem4 = new MenuItem("Close");
        MenuItem menuItem5 = new Menu("Help");

        menuItem1.setOnAction(event -> openFile(primaryStage));
        menuItem2.setOnAction(event -> saveFile(primaryStage));
        menuItem3.setOnAction(event -> saveCurrentFile());
        menuItem4.setOnAction(event -> primaryStage.close());
        menuItem5.setOnAction(event -> showHelpDialog());
        //menuItem6.setOnAction(event -> handleEditMenuItem());

        menu1.getItems().addAll(menuItem1, menuItem2, menuItem3, menuItem4, menuItem5);
        menuBar.getMenus().addAll(menu1);
        menuBar.getMenus().addAll(menuItem5);

        StackPane root = new StackPane();
        root.getChildren().addAll(canvas, menuBar);



    private void openFile(Stage primaryStage) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Open Image File");
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.jpeg", "*.gif", "*.bmp")
        );
        File selectedFile = fileChooser.showOpenDialog(primaryStage);
        if (selectedFile != null) {
            Image image = new Image(selectedFile.toURI().toString());
            gc.drawImage(image, 0, 0, canvas.getWidth(), canvas.getHeight());
        }
    }

    private void saveFile(Stage primaryStage) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("SaveAs");
        fileChooser.getExtensionFilters().addAll(new FileChooser.ExtensionFilter("PNG Files", "*.png"), new FileChooser.ExtensionFilter("JPEG Files", "*.jpg", "*.jpeg")
        );
        File selectedFile = fileChooser.showSaveDialog(primaryStage);
        if (imageView.getImage() != null && selectedFile != null) {
            Image imageToSave = imageView.getImage();                                   //store image inside imageToSave
            String format = selectedFile.getName().toLowerCase().endsWith(".png") ? "png" : "jpg";
            BufferedImage bImage = SwingFXUtils.fromFXImage(imageView.getImage(), null);
            try {
                ImageIO.write(bImage, format, selectedFile);
                lastSavedFile = selectedFile;
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private void saveCurrentFile() {
        if (imageView.getImage() != null && lastSavedFile != null) {
            Image imageToSave = imageView.getImage();                                   //store image inside imageToSave
            String format = lastSavedFile.getName().toLowerCase().endsWith(".png") ? "png" : "jpg";
            BufferedImage bImage = SwingFXUtils.fromFXImage(imageView.getImage(), null);
            try {
                ImageIO.write(bImage, format, lastSavedFile);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private void showHelpDialog() {
        Alert helpDialog = new Alert(Alert.AlertType.INFORMATION);
        helpDialog.setTitle("Help");
        helpDialog.setHeaderText("Helpful Info");
        helpDialog.setContentText("this is information to help you");

        helpDialog.showAndWait();
    }

 */







    /*private void Edit(Canvas canvas, Image img) {
        GraphicsContext gc = canvas.getGraphicsContext2D();
        gc.drawImage(img, 0, 0, canvas.getWidth(), canvas.getHeight());
    }



    private void updateImageInFirstWindow(Image newImage) {
        imageView.setImage(newImage);
    }

    private void handleEditMenuItem(){
        if (imageView != null && imageView.getImage() != null){
            final Image drawImage = imageView.getImage();

            Edit(canvas, drawImage);

            Canvas editCanvas = new Canvas(800, 600);
            GraphicsContext editGC = canvas.getGraphicsContext2D();

            //ints for line width
            AtomicInteger x = new AtomicInteger(5);
            AtomicInteger y = new AtomicInteger(5);
            editCanvas.addEventHandler(MouseEvent.MOUSE_DRAGGED, e -> {
                editGC.setFill(Color.RED);
                editGC.fillRect(e.getX() - 2, e.getY() - 2, x.get(), y.get());
            });

            // Create a button
            Button clearButton = new Button("Clear");
            clearButton.setTranslateX(0);
            clearButton.setTranslateY(10);
            clearButton.setOnAction(e -> {
                // Add action for clearing the canvas
                editGC.clearRect(0,0, editCanvas.getWidth(), editCanvas.getHeight());
            });

            //Size up
            Button sizeUpButton = new Button("Size up");
            sizeUpButton.setTranslateX(100);
            sizeUpButton.setTranslateY(10);
            sizeUpButton.setOnAction(e -> {
                x.incrementAndGet();
                y.incrementAndGet();
            });

            //Size Down
            Button sizeDownButton = new Button("Size down");
            sizeDownButton.setTranslateX(170);
            sizeDownButton.setTranslateY(10);
            sizeDownButton.setOnAction(e -> {
                x.decrementAndGet();
                y.decrementAndGet();
            });

            //Saves the edited image and inputs into other window
            Button saveChangedImg = new Button("Save");
            saveChangedImg.setTranslateX(50);
            saveChangedImg.setTranslateY(10);
            saveChangedImg.setOnAction(e -> {
                if (currentFile != null) {
                    //Takes a pic of img
                    Image snapshot = canvas.snapshot(null, null);
                    //updates img
                    updateImageInFirstWindow(snapshot);
                }
            });

            //Color picker
            ColorPicker colorPicker = new ColorPicker();
            colorPicker.setValue(Color.RED);
            colorPicker.setTranslateX(250);
            colorPicker.setTranslateY(10);

            //Attempted edit menu bar
            Menu editImg = new Menu();
            MenuBar editMenu = new MenuBar();
            //editImg.getItems().add(clearButton, saveChangedImg);
            editMenu.getMenus().addAll(editImg);

            //New window
            StackPane editRoot = new StackPane();
            editRoot.getChildren().addAll(editCanvas, clearButton, sizeDownButton, sizeUpButton, colorPicker, saveChangedImg);
            Stage secondStage = new Stage();
            secondStage.setTitle("Canvas");
            secondStage.setScene(new Scene(root, 800, 700));
            secondStage.show();

        }


}
*/