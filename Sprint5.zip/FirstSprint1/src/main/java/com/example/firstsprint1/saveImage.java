/**
 * This class saves the content on the canvas to a image file
 * Also includes the auto-feature
 */
package com.example.firstsprint1;

import javafx.embed.swing.SwingFXUtils;
import javafx.scene.SnapshotParameters;
import javafx.scene.canvas.Canvas;
import javafx.scene.image.Image;
import javafx.scene.image.WritableImage;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.awt.image.RenderedImage;
import java.io.File;
import java.io.IOException;
import java.util.Timer;
import java.util.TimerTask;

public class saveImage {
    private File currentImageFile = null;
    private boolean unsavedChanges = false;
    private Timer autoSaveTimer;
    private static final int AUTO_SAVE_INTERVAL = 60000;
    private Canvas canvas;
    private boolean autoSaveEnabled = true;

    public saveImage(){
        autoSaveTimer = new Timer(true);
        autoSaveTimer.schedule(new AutoSaveTask(),AUTO_SAVE_INTERVAL, AUTO_SAVE_INTERVAL);
    }

    public void saveImg(Canvas canvas, File imageFile) {
        if (canvas != null && imageFile != null) {
            int width = (int) canvas.getWidth();
            int height = (int) canvas.getHeight();

            WritableImage writableImage = new WritableImage(width, height);         // Create writable image with the same dimensions as the Canvas
            Image img = canvas.snapshot(new SnapshotParameters(), writableImage);               // Take snapshot of the Canvas content

            //RenderedImage rImg = SwingFXUtils.fromFXImage(writableImage, null);
            BufferedImage bImage = SwingFXUtils.fromFXImage(img, null);     // Converting the Writable Image to a Buffered Image

            String format = imageFile.getName().toLowerCase().endsWith(".png") ? "png" : "jpg";
            try {
                ImageIO.write(bImage, format, imageFile);   // Write BufferedImage to specified image file
                System.out.println("Image Saved at: " + imageFile.getAbsolutePath());
                currentImageFile = imageFile;
                unsavedChanges = false;
            } catch (IOException e) {
                e.printStackTrace();                                // Handle any input/output exceptions that may occur
            }
        }
    }
    public File getCurrentImageFile(){
        return currentImageFile;
    }

    public void startAutoSave() {
        autoSaveEnabled = true;
        if (autoSaveTimer == null) {
            // Initialize the auto-save timer
            autoSaveTimer = new Timer(true);
            autoSaveTimer.schedule(new AutoSaveTask(), AUTO_SAVE_INTERVAL, AUTO_SAVE_INTERVAL);
        }
    }

    public void stopAutoSave() {
        autoSaveEnabled = false;
        if (autoSaveTimer != null) {
            // Cancel the auto-save timer
            autoSaveTimer.cancel();
            autoSaveTimer = null;
        }
    }
    class AutoSaveTask extends TimerTask{
        @Override
        public void run(){
            if (unsavedChanges && currentImageFile != null){
                saveImg(canvas, currentImageFile);
                unsavedChanges = false;
                System.out.println("Auto-saved.");
            } else {
                System.out.println("Auto-save skipped: Auto-save did not detect a file.");
            }
        }
    }
}
