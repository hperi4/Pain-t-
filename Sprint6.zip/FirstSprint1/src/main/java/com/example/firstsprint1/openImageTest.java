/*package com.example.firstsprint1;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.canvas.Canvas;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import org.junit.jupiter.api.Test;

import java.io.File;


import static javafx.beans.binding.Bindings.when;

public class openImageTest {
    private JavaFXApp javaFXApp;
    private DrawingLine drawingLine;
    private GraphicsContext graphicsContext;

    @Test
    public void testOpenImg() {
        Stage stage = mock(Stage.class);
        Canvas canvas = mock(Canvas.class);
        FileChooser fileChooser = mock(FileChooser.class);
        File selectedFile = new File("test-image.jpg");
        when(fileChooser.showOpenDialog(stage)).thenReturn(selectedFile);
        openImage imageOpener = new openImage();

        verify(canvas).setWidth(anyDouble());
        verify(canvas).setHeight(anyDouble());
        verify(canvas.getGraphicsContext2D()).drawImage(any(), eq(0.0), eq(0.0));

        assert (result != null);
        assert (result.getName().equals("test-image.jpg"));
    }
}

 */


