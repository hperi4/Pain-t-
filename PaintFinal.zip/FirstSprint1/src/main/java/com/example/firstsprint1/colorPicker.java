/**
 * Class allows the user to select a color for drawing line.
 */

package com.example.firstsprint1;

import javafx.scene.Scene;
import javafx.scene.control.ColorPicker;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.scene.paint.Color;

public class colorPicker {
   DrawingLine CLine = new DrawingLine(600, 800);
    private Color setStroke = Color.BLACK;
    public void showColorPicker() {
        ColorPicker colorPicker = new ColorPicker(setStroke); // Create a ColorPicker control
        VBox vbox = new VBox(colorPicker);

        Stage colorPickerStage = new Stage();
        colorPickerStage.setTitle("Color Picker");

        Scene scene = new Scene(vbox, 200, 100);

        colorPickerStage.setScene(scene);
        colorPickerStage.show();

        colorPicker.setValue(setStroke);
        colorPicker.setOnAction(event -> {
            setStrokeColor(colorPicker.getValue());
        });
    }
    public void setStrokeColor(Color color){
        this.setStroke = color;
        CLine.colorPicker(setStroke);
    }
}

