/**
 * Class represents a canvas for drawing lines and shapes.
 * Provides methods for changing color, line width, enabling/disabling drawing and erasing.
 * Responds to mouse event press, drag, and release.
 */
package com.example.firstsprint1;

import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.canvas.Canvas;

import java.io.File;

public class DrawingLine extends Canvas {
    private GraphicsContext gc;
    private int linewidth = 2;
    private Color fillColor = Color.BLACK;
    private boolean isDrawingEnabled = false;

    /**
     * Constructs an instance of the DrawingLine class, representing a canvas for drawing lines.
     *
     * @param width The width of the drawing canvas.
     * @param height The height of the drawing canvas.
     //* @param canvas The Canvas object representing the drawing canvas.
     *
     * The constructor initializes the Canvas with the specified width and height. It obtains
     * the GraphicsContext for drawing on the canvas, sets the line width and stroke color, and
     * registers event handlers for mouse interactions (pressed, dragged, and released) to handle
     * the drawing process.
     */
    public DrawingLine(double width, double height) {     // Constructor for the DrawingCanvas class, taking width and height as parameters
        super(width, height);                                   // Call constructor of the Canvas class with specified width and height
        gc = getGraphicsContext2D();                            // Get GraphicsContext for drawing on the canvas
        gc.setLineWidth(linewidth);
        gc.setStroke(Color.BLACK);

        setOnMousePressed(this::startDrawing);                  // When mouse pressed call startDrawing method
        setOnMouseDragged(this::continueDrawing);               // When mouse dragged call continueDrawing method
        setOnMouseReleased(this::stopDrawing);                  // When mouse released call stopDrawing method
    }
    public void colorPicker(Color color) {
        gc.setStroke(color);
    }

    /**
     * Initiates the drawing process when the mouse is pressed.
     *
     * @param event The MouseEvent representing the mouse press event.
     *
     * If drawing is enabled, the method begins a new path for drawing on the canvas.
     * It then moves the drawing cursor to the location of the mouse click and performs
     * a stroke operation to start the drawing process.
     */
    public void startDrawing(MouseEvent event) {
        if (isDrawingEnabled){
            gc.beginPath();                                          // Begin new path for drawing
            gc.lineTo(event.getX(), event.getY());                   // Move drawing cursor to mouse click location
            gc.stroke();                                             // Perform stroke operation to start drawing
        }
    }

    /**
     * Continues the drawing process as the mouse is dragged.
     * @param event The MouseEvent representing the mouse drag event.
     *
     * If drawing is enabled, the method extends the current path to the current mouse position.
     * It then performs a stroke operation to continue the drawing process.
     */
    private void continueDrawing(MouseEvent event) {
        if (isDrawingEnabled){
            gc.lineTo(event.getX(), event.getY());                    // Extend path to current mouse position
            gc.stroke();                                              // Perform stroke operation to continue drawing
        }
    }

    /**
     * Ends the drawing process when the mouse is released.
     *
     * @param event The MouseEvent representing the mouse release event.
     *
     * If drawing is enabled, the method closes the current path, effectively ending the drawing process.
     * This is typically called when the mouse is released after drawing has been initiated.
     */
    private void stopDrawing(MouseEvent event) {
        if (isDrawingEnabled){
            gc.closePath();
        }
    }

    /**
     * Sets the drawing mode to either enabled or disabled.
     *
     * @param enabled A boolean value indicating whether drawing mode should be enabled (true) or disabled (false).
     *
     * The method allows you to control whether drawing actions should be enabled or disabled on the canvas.
     * If set to true, drawing actions like mouse press, drag, and release will be processed; otherwise, they
     * will be ignored.
     */
    public void setDrawingEnabled(boolean enabled){
        isDrawingEnabled = enabled;
    }

    /**
     * Checks whether drawing mode is currently enabled.
     * @return True if drawing mode is enabled, false otherwise.
     * The method returns a boolean indicating whether drawing actions are currently enabled on the canvas.
     */
    public boolean isDrawingEnabled(){
        return this.isDrawingEnabled;
    }

    /**
     * Sets the line width for drawing on the canvas.
     *
     * @param newWidth The new line width to be set.
     *
     * The method updates the line width for drawing on the canvas to the specified value.
     */
    public void setLwidth(int newWidth) {
        linewidth = newWidth;                           // Update line width
        gc.setLineWidth(linewidth);                     // Set new line width in GraphicsContext
    }

    /**
     * Retrieves the current line width for drawing on the canvas.
     *
     * @return The current line width for drawing.
     *
     * The method returns the current line width used for drawing on the canvas.
     */
    public int getLwidth() {
        return linewidth;
    }


    /**
     * Erases a portion of the canvas at the specified coordinates with a given eraser size.
     *
     * @param x  The x-coordinate of the center of the erasing area.
     * @param y  The y-coordinate of the center of the erasing area.
     * @param eraserSize The size of the eraser used for clearing the canvas.
     */
    public void erase(double x, double y , double eraserSize){
            GraphicsContext gc = getGraphicsContext2D();
            gc.clearRect(x - eraserSize / 2, y - eraserSize / 2, eraserSize, eraserSize);
    }

    /**
     * Retrieves the Canvas object associated with this instance.
     *
     * @return The Canvas object associated with this instance.
     *
     * The method returns the Canvas object associated with this instance, providing direct access
     * to the canvas for external use or manipulation.
     */
    public Canvas getCanvas(){
        return this;
    }
}


