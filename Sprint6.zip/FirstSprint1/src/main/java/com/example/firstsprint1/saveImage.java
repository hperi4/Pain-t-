/**
 * This class saves the content on the canvas to a image file
 * Also includes the auto-feature
 */
package com.example.firstsprint1;

import javafx.embed.swing.SwingFXUtils;
import javafx.scene.SnapshotParameters;
import javafx.scene.canvas.Canvas;
import javafx.scene.image.Image;
import javafx.scene.image.WritableImage;
import javafx.stage.FileChooser;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.awt.image.RenderedImage;
import java.io.File;
import java.io.IOException;
import java.util.Timer;
import java.util.TimerTask;

public class saveImage {
    private File currentImageFile = null;
    private boolean unsavedChanges = false;
    private Timer autoSaveTimer;
    private static final int AUTO_SAVE_INTERVAL = 60000;
    private Canvas canvas;
    private boolean autoSaveEnabled = true;

    public saveImage(){
        this.canvas = canvas;
        autoSaveTimer = new Timer(true);
        autoSaveTimer.schedule(new AutoSaveTask(currentImageFile),AUTO_SAVE_INTERVAL, AUTO_SAVE_INTERVAL);
    }

    public void saveImg(Canvas canvas, File file) {
        if (canvas != null) {
            int width = (int) canvas.getWidth();
            int height = (int) canvas.getHeight();

            WritableImage writableImage = new WritableImage(width, height);         // Create writable image with the same dimensions as the Canvas
            Image img = canvas.snapshot(new SnapshotParameters(), writableImage);               // Take snapshot of the Canvas content

            //RenderedImage rImg = SwingFXUtils.fromFXImage(writableImage, null);
            BufferedImage bImage = SwingFXUtils.fromFXImage(img, null);     // Converting the Writable Image to a Buffered Image

            String format = currentImageFile.getName().toLowerCase().endsWith(".png") ? "png" : "jpg";
            try {
                ImageIO.write(bImage, format, currentImageFile);   // Write BufferedImage to specified image file
                System.out.println("Image Saved at: " + currentImageFile.getAbsolutePath());
                unsavedChanges = false;
            } catch (IOException e) {
                e.printStackTrace();                                // Handle any input/output exceptions that may occur
            }
        } else {
            saveImgAs(canvas);
        }
    }

    public void saveImgAs(Canvas canvas) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Save As");
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("PNG Files", "*.png"),
                new FileChooser.ExtensionFilter("JPEG Files", "*.jpg", "*.jpeg"),
                new FileChooser.ExtensionFilter("GIF Files", "*.gif"),
                new FileChooser.ExtensionFilter("BMP Files", "*.bmp")
        );
        File selectedFile = fileChooser.showSaveDialog(null);

        if (selectedFile != null) {
            currentImageFile = selectedFile; // Update currentImageFile
            //saveImg(canvas); // Save the image to the newly selected file
        }
    }
    public File getCurrentImageFile(){
        return currentImageFile;
    }

    public void startAutoSave() {
        autoSaveEnabled = true;
        if (autoSaveTimer == null) {
            // Initialize the auto-save timer
            autoSaveTimer = new Timer(true);
            autoSaveTimer.schedule(new AutoSaveTask(currentImageFile), AUTO_SAVE_INTERVAL, AUTO_SAVE_INTERVAL);
        }
    }

    public void stopAutoSave() {
        autoSaveEnabled = false;
        if (autoSaveTimer != null) {
            // Cancel the auto-save timer
            autoSaveTimer.cancel();
            autoSaveTimer = null;
        }
    }
    class AutoSaveTask extends TimerTask{
        private File currentFile;

        public AutoSaveTask(File currentFile){
            this.currentFile = currentFile;
        }
        @Override
        public void run(){
            if (unsavedChanges && currentFile != null){
                saveImg(canvas, currentFile);
                unsavedChanges = false;
                System.out.println("Auto-saved.");
            } else {
                System.out.println("Auto-save skipped: Auto-save did not detect a file.");
            }
        }
    }
}
