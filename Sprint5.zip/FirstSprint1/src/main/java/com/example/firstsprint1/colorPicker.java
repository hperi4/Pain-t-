/**
 * Class allows the user to select a color for drawing line.
 */
package com.example.firstsprint1;

import javafx.scene.Scene;
import javafx.scene.control.ColorPicker;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.scene.paint.Color;

public class colorPicker {
    DrawingLine CLine = new DrawingLine(600, 800);
    private Color selectedColor = Color.BLACK;
    public void showColorPicker() {
        ColorPicker colorPicker = new ColorPicker(selectedColor); // Create a ColorPicker control
        VBox vbox = new VBox(colorPicker);

        Stage colorPickerStage = new Stage();
        colorPickerStage.setTitle("Color Picker");

        Scene scene = new Scene(vbox, 200, 100);

        colorPickerStage.setScene(scene);
        colorPickerStage.show();

        //colorPicker.setValue(selectedColor);
        colorPicker.setOnAction(event -> {
            setSelectedColor(colorPicker.getValue());
        });
    }
    public void setSelectedColor(Color color){
        this.selectedColor = color;
        CLine.colorChanger(selectedColor);
    }
}