package com.example.firstsprint1;

import javafx.embed.swing.SwingFXUtils;
import javafx.scene.SnapshotParameters;
import javafx.scene.canvas.Canvas;
import javafx.scene.image.WritableImage;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class saveImage {
    private File currentImageFile = null;
    private boolean unsavedChanges = false;
    public void saveImg(Canvas canvas, File imageFile) {
        if (canvas != null && imageFile != null) {
            int width = (int) canvas.getWidth();
            int height = (int) canvas.getHeight();

            WritableImage writableImage = new WritableImage(width, height);         // Create writable image with the same dimensions as the Canvas
            canvas.snapshot(new SnapshotParameters(), writableImage);               // Take snapshot of the Canvas content

            BufferedImage bImage = SwingFXUtils.fromFXImage(writableImage, null);     // Converting the Writable Image to a Buffered Image

            String format = imageFile.getName().toLowerCase().endsWith(".png") ? "png" : "jpg";
            try {
                ImageIO.write(bImage, format, imageFile);   // Write BufferedImage to specified image file
                currentImageFile = imageFile;
                unsavedChanges = false;
            } catch (IOException e) {
                e.printStackTrace();                                // Handle any input/output exceptions that may occur
            }
        }
    }
    public File getCurrentImageFile(){
        return currentImageFile;
    }
}
